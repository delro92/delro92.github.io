NOGRAPHIC-EMBEDDED
Embedded themes does not contain .theme file nor graphic, that is embedded in PeaZip for maximum startup performances.
This theme is meant to start PeaZip GUI with no graphic icons.